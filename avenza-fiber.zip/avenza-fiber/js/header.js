/**
 * AVENZA FIBER LLP - Header & Mobile Navigation JavaScript
 */

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    const toggleBtn = document.querySelector('.header__toggle');
    const mobileNav = document.querySelector('.mobile-nav');
    const closeBtns = document.querySelectorAll('.mobile-nav__close');
    const backdrop = document.querySelector('.mobile-nav__backdrop');
    const navLinks = document.querySelectorAll('.mobile-nav__link');

    if (!toggleBtn || !mobileNav) return;

    function openMobileMenu() {
      toggleBtn.setAttribute('aria-expanded', 'true');
      mobileNav.classList.add('mobile-nav--open');
      if (backdrop) backdrop.classList.add('mobile-nav__backdrop--open');
      document.body.style.overflow = 'hidden';

      // Focus close button or first link in drawer
      const closeBtn = mobileNav.querySelector('.mobile-nav__close');
      if (closeBtn) {
        closeBtn.focus();
      } else {
        const firstLink = mobileNav.querySelector('a, button');
        if (firstLink) firstLink.focus();
      }
    }

    function closeMobileMenu() {
      toggleBtn.setAttribute('aria-expanded', 'false');
      mobileNav.classList.remove('mobile-nav--open');
      if (backdrop) backdrop.classList.remove('mobile-nav__backdrop--open');
      document.body.style.overflow = '';
      toggleBtn.focus();
    }

    toggleBtn.addEventListener('click', function (e) {
      e.preventDefault();
      const isExpanded = toggleBtn.getAttribute('aria-expanded') === 'true';
      if (isExpanded) {
        closeMobileMenu();
      } else {
        openMobileMenu();
      }
    });

    if (backdrop) {
      backdrop.addEventListener('click', function (e) {
        e.preventDefault();
        closeMobileMenu();
      });
    }

    closeBtns.forEach((btn) => {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        closeMobileMenu();
      });
    });

    // Close on link click
    navLinks.forEach((link) => {
      link.addEventListener('click', closeMobileMenu);
    });

    // Close on Escape key
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && toggleBtn.getAttribute('aria-expanded') === 'true') {
        closeMobileMenu();
      }
    });

    // Highlight current page active link
    const currentPath = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav__link, .mobile-nav__link').forEach((link) => {
      const href = link.getAttribute('href');
      if (
        href === currentPath ||
        (currentPath === '' && href === 'index.html') ||
        (currentPath === 'page-1.html' && href === 'index.html') ||
        (currentPath === 'page-2.html' && href === 'about.html') ||
        (currentPath === 'page-3.html' && href === 'product.html') ||
        (currentPath === 'page-4.html' && href === 'applications.html') ||
        (currentPath === 'page-5.html' && href === 'contact.html')
      ) {
        link.classList.add(link.classList.contains('mobile-nav__link') ? 'mobile-nav__link--active' : 'nav__link--active');
        link.setAttribute('aria-current', 'page');
      }
    });
  });
})();
