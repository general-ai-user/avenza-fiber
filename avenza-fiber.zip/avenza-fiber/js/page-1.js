/**
 * AVENZA FIBER LLP - Page 1: Home Interactive Logic
 * 1. Hero Glassmorphic Benchmark Diameter Switcher
 * 2. Interactive GFRP vs Steel Weight Calculator with Live Visual Gauge
 * 3. Applications Neomorphic Category Filter
 */

(function () {
  'use strict';

  // Specification data per diameter
  const diameterData = {
    6: {
      tensile: '> 1000 MPa',
      gfrpWeight: '0.065 kg/m',
      steelWeight: '0.222 kg/m',
      savings: '71% Lighter',
      gfrpUnit: 0.065,
      steelUnit: 0.222,
      usage: 'Precast elements, light slabs, screeds'
    },
    8: {
      tensile: '> 1000 MPa',
      gfrpWeight: '0.116 kg/m',
      steelWeight: '0.395 kg/m',
      savings: '71% Lighter',
      gfrpUnit: 0.116,
      steelUnit: 0.395,
      usage: 'Driveways, agricultural slabs, footings'
    },
    10: {
      tensile: '> 1000 MPa',
      gfrpWeight: '0.175 kg/m',
      steelWeight: '0.617 kg/m',
      savings: '72% Lighter',
      gfrpUnit: 0.175,
      steelUnit: 0.617,
      usage: 'Swimming pools, boundary walls, foundations'
    },
    12: {
      tensile: '> 1000 MPa',
      gfrpWeight: '0.250 kg/m',
      steelWeight: '0.888 kg/m',
      savings: '72% Lighter',
      gfrpUnit: 0.250,
      steelUnit: 0.888,
      usage: 'Bridge decks, sea walls, highway slabs (Most Common)'
    },
    16: {
      tensile: '> 1000 MPa',
      gfrpWeight: '0.450 kg/m',
      steelWeight: '1.580 kg/m',
      savings: '72% Lighter',
      gfrpUnit: 0.450,
      steelUnit: 1.580,
      usage: 'Heavy civil, industrial floors, coastal docks'
    },
    20: {
      tensile: '> 1000 MPa',
      gfrpWeight: '0.685 kg/m',
      steelWeight: '2.470 kg/m',
      savings: '72% Lighter',
      gfrpUnit: 0.685,
      steelUnit: 2.470,
      usage: 'Marine pilings, water treatment tanks, rail slabs'
    },
    25: {
      tensile: '> 1000 MPa',
      gfrpWeight: '1.070 kg/m',
      steelWeight: '3.850 kg/m',
      savings: '72% Lighter',
      gfrpUnit: 1.070,
      steelUnit: 3.850,
      usage: 'Heavy infrastructure, chemical plants, high-load decks'
    }
  };

  document.addEventListener('DOMContentLoaded', function () {
    initHeroBenchmarkSwitcher();
    initRebarCalculator();
    initAppsFilter();
  });

  /* --------------------------------------------------------------------------
     1. Hero Glassmorphic Benchmark Diameter Switcher
     -------------------------------------------------------------------------- */
  function initHeroBenchmarkSwitcher() {
    const diaButtons = document.querySelectorAll('.hero__dia-btn');
    const heroTensile = document.getElementById('hero-spec-tensile');
    const heroWeight = document.getElementById('hero-spec-weight');
    const heroUsage = document.getElementById('hero-spec-usage');
    const heroSavings = document.getElementById('hero-spec-savings');

    if (!diaButtons.length) return;

    diaButtons.forEach(btn => {
      btn.addEventListener('click', function () {
        const dia = parseInt(this.getAttribute('data-dia'), 10);
        if (!diameterData[dia]) return;

        diaButtons.forEach(b => b.classList.remove('hero__dia-btn--active'));
        this.classList.add('hero__dia-btn--active');

        const info = diameterData[dia];
        if (heroTensile) heroTensile.textContent = info.tensile;
        if (heroWeight) heroWeight.textContent = `${info.gfrpWeight} (Steel: ${info.steelWeight})`;
        if (heroSavings) heroSavings.textContent = info.savings;
        if (heroUsage) heroUsage.textContent = info.usage;
      });
    });
  }

  /* --------------------------------------------------------------------------
     2. Interactive GFRP vs Steel Weight Calculator with Live Visual Gauge
     -------------------------------------------------------------------------- */
  function initRebarCalculator() {
    const diameterSelect = document.getElementById('calc-diameter');
    const chips = document.querySelectorAll('.calc-chip');
    const lengthInput = document.getElementById('calc-length');
    const lengthRange = document.getElementById('calc-length-range');
    const presetBtns = document.querySelectorAll('.calc-preset-btn');

    // Outputs
    const resultGfrpWeight = document.getElementById('res-gfrp-weight');
    const resultSteelWeight = document.getElementById('res-steel-weight');
    const resultSavedWeight = document.getElementById('res-saved-weight');
    const resultSavedPct = document.getElementById('res-saved-pct');
    const barGfrp = document.getElementById('calc-bar-gfrp');
    const barGfrpLabel = document.getElementById('calc-bar-gfrp-label');
    const barSteelLabel = document.getElementById('calc-bar-steel-label');

    if (!lengthInput) return;

    let currentDia = 12;

    function updateCalculations() {
      const meters = Math.max(1, parseFloat(lengthInput.value) || 0);
      const data = diameterData[currentDia] || diameterData[12];

      const totalGfrp = meters * data.gfrpUnit;
      const totalSteel = meters * data.steelUnit;
      const savedWeight = Math.max(0, totalSteel - totalGfrp);
      const savedPct = totalSteel > 0 ? Math.round((savedWeight / totalSteel) * 100) : 72;
      const gfrpRatioPct = totalSteel > 0 ? Math.round((totalGfrp / totalSteel) * 100) : 28;

      if (resultGfrpWeight) resultGfrpWeight.textContent = totalGfrp.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + ' kg';
      if (resultSteelWeight) resultSteelWeight.textContent = totalSteel.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + ' kg';
      if (resultSavedWeight) resultSavedWeight.textContent = savedWeight.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + ' kg';
      if (resultSavedPct) resultSavedPct.textContent = savedPct + '% Lighter';

      // Visual Gauge update
      if (barGfrp) barGfrp.style.width = Math.max(15, gfrpRatioPct) + '%';
      if (barGfrpLabel) barGfrpLabel.textContent = `Avenza GFRP (${totalGfrp.toFixed(0)} kg)`;
      if (barSteelLabel) barSteelLabel.textContent = `Structural Steel (${totalSteel.toFixed(0)} kg)`;
    }

    // Diameter Chips Click Handler
    chips.forEach(chip => {
      chip.addEventListener('click', function () {
        chips.forEach(c => c.classList.remove('calc-chip--active'));
        this.classList.add('calc-chip--active');
        currentDia = parseInt(this.getAttribute('data-dia'), 10) || 12;
        if (diameterSelect) diameterSelect.value = String(currentDia);
        updateCalculations();
      });
    });

    // Dropdown change
    if (diameterSelect) {
      diameterSelect.addEventListener('change', function () {
        currentDia = parseInt(this.value, 10) || 12;
        chips.forEach(c => {
          if (parseInt(c.getAttribute('data-dia'), 10) === currentDia) {
            c.classList.add('calc-chip--active');
          } else {
            c.classList.remove('calc-chip--active');
          }
        });
        updateCalculations();
      });
    }

    // Range slider sync
    if (lengthRange) {
      lengthRange.addEventListener('input', function () {
        lengthInput.value = this.value;
        updateCalculations();
      });
    }

    // Number input sync
    lengthInput.addEventListener('input', function () {
      if (lengthRange) lengthRange.value = this.value;
      updateCalculations();
    });

    // Preset buttons
    presetBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        const val = this.getAttribute('data-val');
        lengthInput.value = val;
        if (lengthRange) lengthRange.value = val;
        updateCalculations();
      });
    });

    // Initial run
    updateCalculations();
  }

  /* --------------------------------------------------------------------------
     3. Applications Frosted Glass Category Filter
     -------------------------------------------------------------------------- */
  function initAppsFilter() {
    const filterButtons = document.querySelectorAll('.apps-filter-btn');
    const appCards = document.querySelectorAll('.app-glass-card, .app-neo-card');

    if (!filterButtons.length || !appCards.length) return;

    filterButtons.forEach(btn => {
      btn.addEventListener('click', function () {
        const filter = this.getAttribute('data-filter');

        filterButtons.forEach(b => b.classList.remove('apps-filter-btn--active'));
        this.classList.add('apps-filter-btn--active');

        appCards.forEach(card => {
          const category = card.getAttribute('data-category');
          if (filter === 'all' || category === filter) {
            card.style.display = 'flex';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
          } else {
            card.style.display = 'none';
          }
        });
      });
    });
  }
})();
