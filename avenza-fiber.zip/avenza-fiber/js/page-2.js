/**
 * AVENZA FIBER LLP - Page 2: About Us JavaScript
 */

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    // Reveal animated numbers or stat cards if in view
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('fade-in-ready');
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.commit-card, .mv-card, .why-item-card').forEach((el) => {
      observer.observe(el);
    });
  });
})();
