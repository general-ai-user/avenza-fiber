/**
 * AVENZA FIBER LLP - Global Common JavaScript
 * Utilities, scroll effects, back-to-top, catalog download handler
 */

(function () {
  'use strict';

  // Wait for DOM
  document.addEventListener('DOMContentLoaded', function () {
    initScrollProgress();
    initHeaderScroll();
    initBackToTop();
    initCatalogDownloadTrack();
    initGlobalSmoothScroll();
    initScrollReveal();
  });

  // Reading Scroll Progress Indicator (Subtle thin bar at top of viewport)
  function initScrollProgress() {
    let bar = document.querySelector('.scroll-progress-bar');
    if (!bar) {
      bar = document.createElement('div');
      bar.className = 'scroll-progress-bar';
      bar.setAttribute('aria-hidden', 'true');
      document.body.prepend(bar);
    }

    const updateProgress = () => {
      const winScroll = document.documentElement.scrollTop || document.body.scrollTop;
      const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      const scrolled = height > 0 ? (winScroll / height) * 100 : 0;
      bar.style.width = Math.min(100, Math.max(0, scrolled)) + '%';
    };

    window.addEventListener('scroll', updateProgress, { passive: true });
    window.addEventListener('resize', updateProgress, { passive: true });
    updateProgress();
  }

  // Sticky Header glass intensity on scroll
  function initHeaderScroll() {
    const header = document.querySelector('.site-header');
    if (!header) return;

    const handleScroll = () => {
      if (window.scrollY > 20) {
        header.classList.add('site-header--scrolled');
      } else {
        header.classList.remove('site-header--scrolled');
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
  }

  // Back to Top Button
  function initBackToTop() {
    const btn = document.querySelector('.footer__back-to-top');
    if (!btn) return;

    btn.addEventListener('click', function (e) {
      e.preventDefault();
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }

  // Catalog Download Action tracking & user toast notification
  function initCatalogDownloadTrack() {
    const downloadBtns = document.querySelectorAll('.btn--download, a[download]');
    downloadBtns.forEach((btn) => {
      btn.addEventListener('click', function () {
        showDownloadToast('Downloading Avenza GFRP Rebar Technical Catalog (PDF)...');
      });
    });
  }

  // Accessible Toast Notification
  function showDownloadToast(message) {
    let toast = document.getElementById('avenza-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'avenza-toast';
      toast.setAttribute('role', 'status');
      toast.setAttribute('aria-live', 'polite');
      toast.style.cssText = `
        position: fixed;
        bottom: 24px;
        right: 24px;
        background: #2a303c;
        color: #ffffff;
        border-left: 4px solid #eaa143;
        padding: 14px 20px;
        border-radius: 8px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.25);
        font-family: var(--font-body, 'Poppins', sans-serif);
        font-size: 14px;
        font-weight: 500;
        z-index: 99999;
        display: flex;
        align-items: center;
        gap: 10px;
        transform: translateY(100px);
        opacity: 0;
        transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.3s ease;
      `;
      document.body.appendChild(toast);
    }

    toast.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#eaa143" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
      <span>${message}</span>
    `;

    // Animate in
    requestAnimationFrame(() => {
      toast.style.transform = 'translateY(0)';
      toast.style.opacity = '1';
    });

    // Auto dismiss
    setTimeout(() => {
      toast.style.transform = 'translateY(100px)';
      toast.style.opacity = '0';
    }, 4000);
  }

  // Smooth scroll for in-page anchors with sticky header offset
  function initGlobalSmoothScroll() {
    document.querySelectorAll('a[href^="#"]:not([href="#"])').forEach((anchor) => {
      anchor.addEventListener('click', function (e) {
        const targetId = this.getAttribute('href');
        if (!targetId || targetId === '#') return;
        const targetElem = document.querySelector(targetId);
        if (targetElem) {
          e.preventDefault();
          const header = document.querySelector('.site-header');
          const headerOffset = (header ? header.offsetHeight : 80) + 20;
          const elementPosition = targetElem.getBoundingClientRect().top + window.pageYOffset;
          const offsetPosition = elementPosition - headerOffset;

          window.scrollTo({
            top: offsetPosition > 0 ? offsetPosition : 0,
            behavior: 'smooth'
          });

          if (history.pushState) {
            history.pushState(null, null, targetId);
          }
        }
      });
    });
  }

  // Subtle Scroll Reveal Animations using IntersectionObserver
  function initScrollReveal() {
    const revealElements = document.querySelectorAll('.scroll-reveal');
    if (!revealElements.length) return;

    // Accessibility check: immediately reveal if reduced motion is requested or observer unavailable
    const prefersReducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion || !('IntersectionObserver' in window)) {
      revealElements.forEach((el) => el.classList.add('is-revealed'));
      return;
    }

    const observerOptions = {
      root: null,
      rootMargin: '0px 0px -50px 0px',
      threshold: 0.12
    };

    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-revealed');
          obs.unobserve(entry.target);
        }
      });
    }, observerOptions);

    revealElements.forEach((el) => {
      const rect = el.getBoundingClientRect();
      // If already in visible viewport area on load, reveal smoothly
      if (rect.top < window.innerHeight * 0.85) {
        el.classList.add('is-revealed');
      } else {
        observer.observe(el);
      }
    });
  }

  // Export helper utilities for other scripts
  window.Avenza = {
    showToast: showDownloadToast,
    // Unit weights for standard diameters
    gfrpUnitWeights: {
      6: 0.065,
      8: 0.116,
      10: 0.175,
      12: 0.25,
      16: 0.45,
      20: 0.685,
      25: 1.07
    },
    // Standard steel rebar unit weights (approx d^2 / 162 kg/m)
    steelUnitWeights: {
      6: 0.222,
      8: 0.395,
      10: 0.617,
      12: 0.888,
      16: 1.58,
      20: 2.47,
      25: 3.85
    }
  };
})();
