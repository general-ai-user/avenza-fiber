/**
 * AVENZA FIBER LLP - Page 3: Product JavaScript
 * Interactive Rebar Diameter Visualizer & Technical Inspector
 */

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    const tabs = document.querySelectorAll('.diameter-tab-btn');
    const circle = document.getElementById('inspect-circle');
    const labelDia = document.getElementById('inspect-dia-label');
    const valGfrpWeight = document.getElementById('inspect-gfrp-weight');
    const valSteelWeight = document.getElementById('inspect-steel-weight');
    const valSavings = document.getElementById('inspect-savings');
    const valTensile = document.getElementById('inspect-tensile');
    const valStandard = document.getElementById('inspect-standard');

    if (!tabs.length || !circle) return;

    const diameterData = {
      6: { weight: '0.065 kg/m', steel: '0.222 kg/m', sizePx: 32, note: 'Ties, stirrups, crack control mesh, thin precast slabs' },
      8: { weight: '0.116 kg/m', steel: '0.395 kg/m', sizePx: 44, note: 'Footpaths, lightweight pavement slabs, residential driveways' },
      10: { weight: '0.175 kg/m', steel: '0.617 kg/m', sizePx: 56, note: 'Swimming pool walls, water tank slabs, industrial ground flooring' },
      12: { weight: '0.250 kg/m', steel: '0.888 kg/m', sizePx: 68, note: 'Highways, base slabs, bridge approach slabs, box culverts' },
      16: { weight: '0.450 kg/m', steel: '1.580 kg/m', sizePx: 84, note: 'Heavy industrial floors, marine retaining walls, chemical plant foundations' },
      20: { weight: '0.685 kg/m', steel: '2.470 kg/m', sizePx: 104, note: 'Heavy infrastructure, bridge decks, coastal sea defense barriers' },
      25: { weight: '1.070 kg/m', steel: '3.850 kg/m', sizePx: 128, note: 'Deep foundations, port breakwaters, heavy civil engineering structures' }
    };

    tabs.forEach((tab) => {
      tab.addEventListener('click', function () {
        const dia = this.getAttribute('data-dia');
        const data = diameterData[dia];
        if (!data) return;

        tabs.forEach((t) => t.classList.remove('diameter-tab-btn--active'));
        this.classList.add('diameter-tab-btn--active');

        // Update visual circle
        circle.style.width = data.sizePx + 'px';
        circle.style.height = data.sizePx + 'px';

        // Update labels
        if (labelDia) labelDia.textContent = dia + ' mm Nominal Diameter';
        if (valGfrpWeight) valGfrpWeight.textContent = data.weight;
        if (valSteelWeight) valSteelWeight.textContent = data.steel;
        if (valSavings) valSavings.textContent = '≈ 74% Weight Reduction';
        if (valTensile) valTensile.textContent = '> 1000 MPa (Guaranteed)';
        if (valStandard) valStandard.textContent = 'IS 18256:2023 & ASTM D7957 · Ideal for ' + data.note;
      });
    });
  });
})();
