/**
 * AVENZA FIBER LLP - Page 4: Applications JavaScript
 * Sector category filters & smooth display
 */

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    const filterBtns = document.querySelectorAll('.apps-filter-btn');
    const sectorBlocks = document.querySelectorAll('.sector-block');

    if (!filterBtns.length || !sectorBlocks.length) return;

    filterBtns.forEach((btn) => {
      btn.addEventListener('click', function () {
        const filter = this.getAttribute('data-filter');

        filterBtns.forEach((b) => b.classList.remove('apps-filter-btn--active'));
        this.classList.add('apps-filter-btn--active');

        sectorBlocks.forEach((block) => {
          const category = block.getAttribute('data-category');
          if (filter === 'all' || category === filter) {
            block.style.display = 'block';
            block.style.opacity = '1';
          } else {
            block.style.display = 'none';
          }
        });
      });
    });
  });
})();
