/**
 * AVENZA FIBER LLP - Style Guide JavaScript
 * Section scroll spy & token copy-to-clipboard
 */

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    initScrollSpy();
    initCopyTokens();
  });

  function initScrollSpy() {
    const sections = document.querySelectorAll('.sg-section');
    const navLinks = document.querySelectorAll('.styleguide-nav__link');

    if (!sections.length || !navLinks.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = entry.target.getAttribute('id');
            navLinks.forEach((link) => {
              if (link.getAttribute('href') === '#' + id) {
                link.classList.add('styleguide-nav__link--active');
              } else {
                link.classList.remove('styleguide-nav__link--active');
              }
            });
          }
        });
      },
      { rootMargin: '-100px 0px -70% 0px' }
    );

    sections.forEach((sec) => observer.observe(sec));
  }

  function initCopyTokens() {
    document.querySelectorAll('.swatch-token, .swatch-hex').forEach((el) => {
      el.style.cursor = 'pointer';
      el.title = 'Click to copy';
      el.addEventListener('click', function () {
        const text = this.textContent.trim();
        navigator.clipboard.writeText(text).then(() => {
          if (window.Avenza?.showToast) {
            window.Avenza.showToast(`Copied token to clipboard: ${text}`);
          }
        });
      });
    });
  }
})();
