/**
 * AVENZA FIBER LLP - Page 5: Contact JavaScript
 * Enquiry form validation & FAQ Accordion
 */

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    preselectProjectType();
    initFaqAccordion();
    initContactForm();
  });

  // Pre-select Project Type from URL query params (e.g. ?type=Road)
  function preselectProjectType() {
    const params = new URLSearchParams(window.location.search);
    const type = params.get('type') || params.get('project');
    if (!type) return;
    const select = document.getElementById('enq-project-type');
    if (!select) return;
    const match = Array.from(select.options).find(function (opt) {
      return opt.value.toLowerCase() === type.toLowerCase() ||
             opt.text.toLowerCase().includes(type.toLowerCase());
    });
    if (match) select.value = match.value;
  }

  // FAQ Accordion
  function initFaqAccordion() {
    const faqItems = document.querySelectorAll('.faq-item');
    if (!faqItems.length) return;

    faqItems.forEach((item) => {
      const button = item.querySelector('.faq-question');
      if (!button) return;

      button.addEventListener('click', function () {
        const isOpen = item.classList.contains('faq-item--open');

        // Optional: close other open items for clean accordion UX
        faqItems.forEach((other) => {
          if (other !== item) {
            other.classList.remove('faq-item--open');
            const otherBtn = other.querySelector('.faq-question');
            if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false');
          }
        });

        if (isOpen) {
          item.classList.remove('faq-item--open');
          button.setAttribute('aria-expanded', 'false');
        } else {
          item.classList.add('faq-item--open');
          button.setAttribute('aria-expanded', 'true');
        }
      });
    });
  }

  // Contact Form Validation & Submission
  function initContactForm() {
    const form = document.getElementById('enquiry-form');
    const successAlert = document.getElementById('form-success-alert');
    const errorAlert = document.getElementById('form-error-alert');

    if (!form) return;

    form.addEventListener('submit', function (e) {
      e.preventDefault();

      // Clear previous alerts
      if (successAlert) successAlert.style.display = 'none';
      if (errorAlert) errorAlert.style.display = 'none';

      // Check required fields
      const name = document.getElementById('enq-name')?.value.trim();
      const phone = document.getElementById('enq-phone')?.value.trim();
      const email = document.getElementById('enq-email')?.value.trim();

      if (!name || !phone || !email) {
        if (errorAlert) {
          errorAlert.textContent = 'Please fill out all required fields: Your Name, Phone Number, and Email Address.';
          errorAlert.style.display = 'block';
        }
        return;
      }

      // Basic email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        if (errorAlert) {
          errorAlert.textContent = 'Please enter a valid email address.';
          errorAlert.style.display = 'block';
        }
        return;
      }

      // Collect all form fields
      const company = document.getElementById('enq-company')?.value.trim() || '';
      const projectType = document.getElementById('enq-project-type')?.value.trim() || '';
      const quantity = document.getElementById('enq-quantity')?.value.trim() || '';
      const location = document.getElementById('enq-location')?.value.trim() || '';
      const message = document.getElementById('enq-message')?.value.trim() || '';

      // Collect selected diameters
      const selectedDiameters = [];
      document.querySelectorAll('input[name="diameters"]:checked').forEach((cb) => {
        selectedDiameters.push(cb.value);
      });
      const diametersStr = selectedDiameters.length > 0 ? selectedDiameters.join(', ') : 'Not specified';

      // Format WhatsApp Message
      const waText = 
`*NEW GFRP REBAR INQUIRY - AVENZA FIBER LLP*
────────────────────────────
👤 *Name:* ${name}
🏢 *Company:* ${company || 'N/A'}
📞 *Phone:* ${phone}
✉️ *Email:* ${email}
🏗️ *Project Type:* ${projectType || 'General'}
📏 *Diameters Required:* ${diametersStr}
📦 *Quantity:* ${quantity || 'To be discussed'}
📍 *Delivery Location:* ${location || 'N/A'}
💬 *Project Details / Notes:*
${message || 'Requesting firm quotation and technical data.'}
────────────────────────────
_Sent via avenzafiberllp.com contact form_`;

      const whatsappUrl = `https://wa.me/919274751153?text=${encodeURIComponent(waText)}`;

      // Submit feedback
      const submitBtn = form.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = 'Submitting & Preparing WhatsApp...';

      setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;

        // Auto-open WhatsApp
        try {
          const waLink = document.createElement('a');
          waLink.href = whatsappUrl;
          waLink.target = '_blank';
          waLink.rel = 'noopener noreferrer';
          document.body.appendChild(waLink);
          waLink.click();
          document.body.removeChild(waLink);
        } catch (err) {
          console.log('WhatsApp popup blocked or handled manually:', err);
        }

        // Auto-trigger Catalog Download
        try {
          const dlLink = document.createElement('a');
          dlLink.href = '/assets/files/product-catalog.pdf';
          dlLink.download = 'Avenza-GFRP-Rebar-Catalog.pdf';
          document.body.appendChild(dlLink);
          dlLink.click();
          document.body.removeChild(dlLink);
        } catch (err) {
          console.log('Auto-download handled manually:', err);
        }

        if (successAlert) {
          successAlert.innerHTML = `
            <div style="display: flex; flex-direction: column; gap: 1rem;">
              <div style="display: flex; align-items: flex-start; gap: 0.85rem;">
                <div style="width: 38px; height: 38px; border-radius: 50%; background: #10b981; color: #ffffff; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 1.15rem; flex-shrink: 0; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);">✓</div>
                <div>
                  <h3 style="margin: 0 0 0.35rem; color: #065f46; font-size: 1.25rem;">Quotation Request Sent!</h3>
                  <p style="margin: 0; color: #047857; font-size: 0.95rem; line-height: 1.5;">
                    Thank you, <strong>${name}</strong>! Your inquiry data has been prepared for WhatsApp dispatch to our Morbi plant team at <strong>+91 92747 51153</strong>.
                  </p>
                </div>
              </div>

              <div style="background: rgba(255, 255, 255, 0.7); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 10px; padding: 0.9rem 1.1rem; font-size: 0.88rem; color: #065f46;">
                <strong>Inquiry Summary:</strong> Rebar Diameters: <em>${diametersStr}</em> · Phone: <em>${phone}</em>
              </div>

              <div style="display: flex; gap: 0.85rem; flex-wrap: wrap; margin-top: 0.5rem;">
                <a href="${whatsappUrl}" target="_blank" rel="noopener noreferrer" class="btn btn--whatsapp" style="flex: 1 1 240px;">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2zm.01 1.67c2.2 0 4.26.86 5.82 2.42a8.19 8.19 0 0 1 2.41 5.83c0 4.54-3.7 8.24-8.24 8.24-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.19 8.19 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.24-8.24zm4.52 11.66c-.25-.13-1.47-.72-1.7-.81-.23-.08-.39-.13-.56.13-.17.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.13-1.06-.39-2.02-1.24-.75-.67-1.25-1.49-1.4-1.74-.14-.25-.02-.39.11-.51.11-.11.25-.29.37-.44.13-.14.17-.25.25-.42.08-.17.04-.31-.02-.44-.06-.13-.56-1.34-.76-1.84-.2-.48-.4-.42-.56-.43h-.48c-.17 0-.44.06-.67.31-.23.25-.88.86-.88 2.1 0 1.24.9 2.44 1.03 2.61.13.17 1.78 2.72 4.31 3.81.6.26 1.07.42 1.44.54.61.19 1.16.17 1.6.1.49-.07 1.47-.6 1.68-1.18.21-.58.21-1.08.15-1.18-.06-.1-.23-.17-.48-.29z"/></svg>
                  <span>Chat on WhatsApp (+91 92747 51153)</span>
                </a>
                <a href="/assets/files/product-catalog.pdf" download="Avenza-GFRP-Rebar-Catalog.pdf" class="btn btn--download" style="flex: 1 1 240px;">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                  <span>Download Product Catalog (PDF)</span>
                </a>
              </div>
            </div>
          `;
          successAlert.style.display = 'block';
          successAlert.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
        form.reset();
      }, 600);
    });
  }
})();
