import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    build: {
      rollupOptions: {
        input: {
          main: path.resolve(__dirname, 'index.html'),
          about: path.resolve(__dirname, 'about.html'),
          product: path.resolve(__dirname, 'product.html'),
          applications: path.resolve(__dirname, 'applications.html'),
          contact: path.resolve(__dirname, 'contact.html'),
          styleguide: path.resolve(__dirname, 'styleguide.html'),
          page1: path.resolve(__dirname, 'page-1.html'),
          page2: path.resolve(__dirname, 'page-2.html'),
          page3: path.resolve(__dirname, 'page-3.html'),
          page4: path.resolve(__dirname, 'page-4.html'),
          page5: path.resolve(__dirname, 'page-5.html'),
        },
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
